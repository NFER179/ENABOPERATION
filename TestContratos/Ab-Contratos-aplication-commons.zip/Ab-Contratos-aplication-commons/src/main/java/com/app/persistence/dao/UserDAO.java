package com.app.persistence.dao;

/* User Data Access Object */
public interface UserDAO {

}
