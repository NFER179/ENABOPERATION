package com.app.persistence.imp;

import java.util.List;

import com.app.persistence.dao.*;

public class UserImp implements UserDAO {
}