package com.app.persistence.connection;

public class ConnectorDB {

}
