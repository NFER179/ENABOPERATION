package com.app.persistence.dao;

import java.util.List;

/* Common Data Access Object. */
public interface CommonDAO {
	
	/**
	 * @author nfernandez
	 */
	public List<Object> getAll();
}
