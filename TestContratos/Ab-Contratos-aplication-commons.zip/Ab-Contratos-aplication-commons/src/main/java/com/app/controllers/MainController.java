package com.app.controllers;

public class MainController {
	
	public MainController() {
		System.out.println("[Controller] -> Start");
		
		/* Cargar Datos de la base de datos. */
		
		
		System.out.println("[Controller] -> End");
	}
}
