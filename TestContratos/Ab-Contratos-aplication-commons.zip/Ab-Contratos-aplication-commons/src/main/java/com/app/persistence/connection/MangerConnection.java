package com.app.persistence.connection;

import com.app.model.dto.ConnectionDTO;

public class MangerConnection {
	
	private ConnectionDTO cnntnDTO;
	
}